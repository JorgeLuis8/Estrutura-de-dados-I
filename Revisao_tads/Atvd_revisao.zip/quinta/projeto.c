typedef struct projeto{
    char nome [100];
    int dataInicio;
    int dataConclusao;
};
