typedef struct jogador Jogador;

Jogador* atrubuir(Jogador *j,int numjogador, int qtd_jogadores);
void imprimir(Jogador *j,int numjogador);
float soma(Jogador *j,int numjogador);
void ehBom(Jogador *j,int numjogador);
void liberar(Jogador *j);

