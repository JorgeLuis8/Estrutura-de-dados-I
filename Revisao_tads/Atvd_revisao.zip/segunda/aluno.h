typedef struct aluno Aluno;
Aluno* atribuir(Aluno *a,int numaluno,int qtd_aluno);
void imprimir(Aluno *a,int numaluno);
void media(Aluno *a,int numaluno);
void aprovacao(Aluno *a,int numaluno);
void liberar(Aluno *a);